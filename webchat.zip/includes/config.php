<?php
$con = mysql_connect('localhost', 'root', '123');
   mysql_select_db("chatroom", $con);
   if (!$con)
   {
   die('Could not connect: ' . mysql_error());
   }
?>
