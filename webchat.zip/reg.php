<?php
$err = $_GET['err'];
$err_msg = "";
if($err!="") {
	switch($err) {
		case 0: $err_msg = "Incomplete form";
			break;
		case 1: $err_msg = "Passwords donot match";
			break;
		case 2: $err_msg = "Already registered or try different username or ID";
			break;
		default:$err_msg = "";
			break;
	}
}
?>
<html>
<head><title>Friends Forever</title>
  <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /></head>
<body>

	<div class="col-lg-6 col-sm-12 col-md-6 col-xs-12" style="margin: auto;">
    <div class="panel panel-success">
        <div class="panel-heading"><h3>Friends Register</h3></div>
        <div class="panel-body">
	
		<form action='submit.php' method="POST" class="form-horizontal">
		
			Username: <input class="form-control" type='text' name='user' />
		
			User ID: <input class="form-control" type='text' name='enroll' />	
		
			Password: <input class="form-control" type='password' name='pass' />
		
			Re-Password: <input class="form-control" type='password' name='re-pass' />
		
			<input type='submit' class="btn-success" value='Register' /> or  <a href = 'index.php' >Login</a>
		
			<span id='err_submit' style='color:red; font-size:12px;'><?php echo $err_msg; ?></span>
		
		</form>
	</div>
	</div>
	</div>
</body>
</html>
