<?php
header('location:chat.php');
?>
