<?php
require('includes/init.php');
if(check_login()==true){
	header('location: chat/chat.php');
}
?>

<html>
<head><title>Friends Forever</title>
  <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /></head>
<body>
<div class="col-lg-6 col-sm-12 col-md-6 col-xs-12" style="margin: auto;">
    <div class="panel panel-success">
        <div class="panel-heading"><h3>Friends Login</h3></div>
        <div class="panel-body">
<form action="login.php" method="POST" class="form-horizontal" >
ID:<input class="form-control" type="text" name="user">


Password:<input class="form-control" type="password" name="pass">


<input class="btn-success" type="submit" name="login" value="login"> or <a href='reg.php'>SignUp</a>

</form>
</div>
</div>
</div>
</body>
</html>
